const userModel = {
  name: "Anderson",
  email: "anderson@donaire.com.br",
  password: "123",
};

module.exports = userModel;
