const formatResponse = (message) => {
    return {
        status: 'success',
        message: message
    }
}       

module.exports = {formatResponse};
